"""Análise exploratória das finais da Libertadores e indicador para 2026.

O índice calculado é heurístico e ilustrativo. Não é um modelo estatístico
calibrado e os percentuais NÃO são probabilidades reais de vitória.
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
OUTPUT_DIR = ROOT / "outputs"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def carregar_dados() -> tuple[pd.DataFrame, pd.DataFrame]:
    finais = pd.read_csv(DATA_DIR / "finais_2023_2025.csv")
    campanha = pd.read_csv(DATA_DIR / "campanha_2026.csv")
    return finais, campanha


def analisar_finais(finais: pd.DataFrame) -> dict[str, float]:
    finais = finais.copy()
    finais["gols_totais"] = finais["gols_campeao"] + finais["gols_vice"]
    return {
        "quantidade_finais": int(len(finais)),
        "media_gols_por_final": float(finais["gols_totais"].mean()),
        "media_gols_campeoes": float(finais["gols_campeao"].mean()),
        "media_gols_vices": float(finais["gols_vice"].mean()),
        "finais_com_prorrogacao": int(finais["prorrogacao"].astype(bool).sum()),
    }


def calcular_indice(campanha: pd.DataFrame) -> pd.DataFrame:
    """Combina, com peso igual, produção ofensiva e indicador defensivo.

    Ofensivo: gols agregados marcados pela equipe / gols agregados de ambas.
    Defensivo: normalização de 1 / (1 + gols agregados sofridos).

    O indicador usa apenas quartas e semifinais de 2026, conforme os dados
    disponíveis neste projeto. O resultado é relativo e não uma probabilidade.
    """
    totais = (
        campanha.groupby("equipe", as_index=False)
        .agg(
            gols_pro=("gols_pro_agregado", "sum"),
            gols_contra=("gols_contra_agregado", "sum"),
            classificacoes_penaltis=("classificou_nos_penaltis", "sum"),
            confrontos=("fase", "count"),
        )
    )

    total_gols_pro = totais["gols_pro"].sum()
    if total_gols_pro == 0:
        totais["indice_ofensivo"] = 0.5
    else:
        totais["indice_ofensivo"] = totais["gols_pro"] / total_gols_pro

    totais["forca_defensiva_bruta"] = 1 / (1 + totais["gols_contra"])
    soma_defesa = totais["forca_defensiva_bruta"].sum()
    totais["indice_defensivo"] = totais["forca_defensiva_bruta"] / soma_defesa
    totais["indice_relativo"] = (
        totais["indice_ofensivo"] + totais["indice_defensivo"]
    ) / 2
    totais["indice_relativo_pct"] = totais["indice_relativo"] * 100
    return totais.sort_values("indice_relativo_pct", ascending=False).reset_index(drop=True)


def gerar_grafico_finais(finais: pd.DataFrame) -> Path:
    fig, ax = plt.subplots(figsize=(9, 5.5))
    anos = finais["ano"].astype(str)
    ax.bar(anos, finais["gols_campeao"], label="Gols do campeão")
    ax.bar(
        anos,
        finais["gols_vice"],
        bottom=finais["gols_campeao"],
        label="Gols do vice",
    )
    ax.set_title("Gols nas finais da Libertadores (2023–2025)")
    ax.set_xlabel("Ano da final")
    ax.set_ylabel("Gols na partida")
    ax.legend()
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    caminho = OUTPUT_DIR / "gols_finais_2023_2025.png"
    fig.savefig(caminho, dpi=160, bbox_inches="tight")
    plt.close(fig)
    return caminho


def gerar_grafico_projecao(indice: pd.DataFrame) -> Path:
    dados = indice.sort_values("indice_relativo_pct", ascending=True)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    barras = ax.barh(dados["equipe"], dados["indice_relativo_pct"])
    ax.set_xlim(0, 100)
    ax.set_title("Índice relativo exploratório — final de 2026")
    ax.set_xlabel("Índice relativo (%) — não é probabilidade de vitória")
    ax.grid(axis="x", alpha=0.25)
    ax.bar_label(barras, fmt="%.1f%%", padding=4)
    fig.tight_layout()
    caminho = OUTPUT_DIR / "indice_projecao_2026.png"
    fig.savefig(caminho, dpi=160, bbox_inches="tight")
    plt.close(fig)
    return caminho


def salvar_resumo(estatisticas: dict[str, float], indice: pd.DataFrame) -> Path:
    linhas = [
        "RESUMO DA ANÁLISE — LIBERTADORES",
        "",
        f"Finais analisadas: {estatisticas['quantidade_finais']}",
        f"Média de gols por final: {estatisticas['media_gols_por_final']:.2f}",
        f"Média de gols dos campeões: {estatisticas['media_gols_campeoes']:.2f}",
        f"Média de gols dos vice-campeões: {estatisticas['media_gols_vices']:.2f}",
        f"Finais com prorrogação: {estatisticas['finais_com_prorrogacao']}",
        "",
        "ÍNDICE RELATIVO PARA 2026 (NÃO É PROBABILIDADE REAL)",
    ]
    for _, linha in indice.iterrows():
        linhas.append(
            f"{linha['equipe']}: {linha['indice_relativo_pct']:.1f}% de índice relativo; "
            f"gols pró agregados={int(linha['gols_pro'])}; "
            f"gols contra agregados={int(linha['gols_contra'])}."
        )
    linhas += [
        "",
        "Interpretação: o índice combina, com peso igual, a participação nos gols "
        "marcados e um indicador relativo de contenção de gols sofridos.",
        "A amostra é muito pequena (quartas e semifinais de uma única edição), "
        "os adversários são diferentes e o índice não considera elencos, lesões, "
        "mando, odds ou desempenho completo da temporada. Use como exercício "
        "exploratório, não como previsão confiável.",
    ]
    caminho = OUTPUT_DIR / "resumo_analise.txt"
    caminho.write_text("\n".join(linhas) + "\n", encoding="utf-8")
    return caminho


def main() -> None:
    finais, campanha = carregar_dados()
    estatisticas = analisar_finais(finais)
    indice = calcular_indice(campanha)

    gerar_grafico_finais(finais)
    gerar_grafico_projecao(indice)
    salvar_resumo(estatisticas, indice)

    print("=== ANÁLISE HISTÓRICA ===")
    for chave, valor in estatisticas.items():
        print(f"{chave}: {valor:.2f}" if isinstance(valor, float) else f"{chave}: {valor}")
    print("\n=== ÍNDICE RELATIVO 2026 (não é probabilidade real) ===")
    print(indice[["equipe", "gols_pro", "gols_contra", "indice_relativo_pct"]].to_string(index=False))
    print(f"\nGráficos e resumo salvos em: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
